import styled from "styled-components";

const CarouselItem = styled.div`
  font-size: 10px;
  line-height: 12px;
  color: #aaaaaa;
  text-align: center;
  padding: 10px;
`;

export default CarouselItem;
